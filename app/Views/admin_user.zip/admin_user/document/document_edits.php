<!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">

      <div class="toast-body text-white">

      </div>

    </div>

    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>

    <!-- Content Header (Page header) -->

    <div class="content-header">

      <div class="container-fluid">

        <div class="row mb-2">

          <div class="col-sm-6">

            <h1 class="m-0"><?php echo $doc['document_type']; ?></h1>

          </div><!-- /.col -->



        </div><!-- /.row -->

            <hr class="border-primary">

      </div><!-- /.container-fluid -->

    </div>

    <!-- /.content-header -->



    <!-- Main content -->

    <section class="content">

      <div class="container-fluid">

<div class="row mb-2">

          



    

     

    <?php if (session('msg')=='Data Not Updated.') { ?>

        <div class="alert alert-danger alert-dismissible" style="width:100%">

            <?= session('msg') ?>

            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>

        </div>



      <?php }else{ ?>

<?php if(session('msg')){?>

<div class="alert alert-info alert-dismissible" style="width:100%">

            <?= session('msg') ?>

            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>

        </div>



    <?php }} ?>

 

   

      <div class="col-md-9">
        <form method="post" id="update_tender" name="update_tender" action="<?= site_url('/DashboardController/document_update') ?>">
                  <input type="hidden" name="id" id="id" value="<?php echo $doc['id']; ?>">
                  <div class="row">
                    <div class="col-sm-12"><h4>Basic Details</h4></div>
                    

        <table class="table table-bordered table-bordered" id="dynamic_field">
                      <tr>
                        <td><h6>Document Type</h6>
                          <select id="Select1" name="document_type[]" class="Modified-Select" >
                            <option value="Technical" <?php if($doc['document_type']=='Technical'){ echo"selected=selected";}?> >Technical </option>
                            <option value="Financial" <?php if($doc['document_type']=='Financial'){ echo"selected=selected";}?>>Financial </option>
                            <option value="Common Document" <?php if($doc['document_type']=='Common Document'){ echo"selected=selected";}?>>Common Document </option>
                            <option value="One time Document" <?php if($doc['document_type']=='One time Document'){ echo"selected=selected";}?>>One time Document </option>
                          </select>
                        </td>
                        <td><h6>Documents Name</h6><input autocomplete="off" class="form-control Modified-file" type="text" name="document_name[]" value="<?php echo $doc['document_name']; ?>" required></td>

                        <td><h6>Documents</h6><input autocomplete="off" class="form-control Modified-file" type="file" name="document_file[]" value="<?php echo $doc['document_file']; ?>"></td>

                        <td><h6>&nbsp;</h6><button type="button" name="add" id="add" class="btn btn-success">+</button></td>  
                      </tr>
                    </table>    
                    <div class="card-footer">                                                
                      <button class="action submit btn btn-sm btn-outline-success float-end">Update</button>
                    </div>
                  </div>
                </form> 

      </div>

 

    </div>

  

</div>

       

      

    </section>

  

  

 

  

  </div>



