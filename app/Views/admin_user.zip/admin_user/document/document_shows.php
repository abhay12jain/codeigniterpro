 <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">

      <div class="toast-body text-white">

      </div>

    </div>

    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>

    <!-- Content Header (Page header) -->

    <div class="content-header">

      <div class="container-fluid">

        <div class="row mb-2">

          <div class="col-sm-6">

            <h1 class="m-0">Tender Document</h1>

          </div><!-- /.col -->



        </div><!-- /.row -->

            <hr class="border-primary">

      </div><!-- /.container-fluid -->

    </div>

    <!-- /.content-header -->



    <!-- Main content -->

    <section class="content">

      <div class="container-fluid">

<div class="row mb-2">

          



    

     

    <?php if (session('msg')=='Data Not Added.') { ?>

        <div class="alert alert-danger alert-dismissible" style="width:100%">

            <?= session('msg') ?>

            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>

        </div>



      <?php }else{ 

       if(session('msg')){?>

        <div class="alert alert-info alert-dismissible" style="width:100%">

            <?= session('msg') ?>

            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>

        </div>

    <?php }} ?>

 

   

  <div class="d-flex justify-content-end mb-4">
                                        <!-- <a href="<?//php echo site_url('/admin/document_data') ?>" class="btn btn-sm btn-outline-secondary">Upload Document</a>
                                    </div class="mt-3"> -->
                                    
                                    <form method="post" id="update_user" action="<?= site_url('/DashboardController/document_info') ?>">
                                              
                                        <table class="table table-hover table-bordered">
                                            <thead>
                                                <tr>
                                                    <th colspan="1">#</th>                                                    
                                                    <th colspan="1">Document Type</th>                                            
                                                    <th colspan="1">Document Name</th>                                                    
                                                    <th colspan="1">Document</th>                                                    
                                                    <th colspan="1">Status</th>
                                                    <th colspan="1">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if($doc): ?>
                                                <?php foreach($doc as $user): ?>
                                                <tr>
                                                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                                    
                                                    <td><?php echo $user['id']; ?></td>                                               
                                                    <td><?php echo $user['document_type']; ?></td>
                                                    <td><?php echo $user['document_name']; ?></td>
                                                    <td><?php echo $user['document_file']; ?></td>
                                                    <td><?php echo $user['status']; ?></td>
                                                    
                                                    
                                                    <td>
                                                         

                                                        <!-- <a href="<?//php echo base_url('/DashboardController/document_views/'.$user['id']);?>" class="text-dark pe-2" ><i class="fas fa-eye"></i></a> -->
                                                        
                                                        <a href="<?php echo base_url('/DashboardController/document_edit/'.$user['id']);?>" class="text-dark pe-2" ><i class="fas fa-edit"></i></a>
                                                        
                                                        <a href="<?php echo base_url('DashboardController/document_delete/'.$user['id']);?>" class="text-dark" onclick="return confirm('Are you sure you want to delete?');" ><i class="fas fa-trash"></i></a>

                                                             
                                                        
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </form>





      </div>

 

    </div>

  </div>

</section>

</div>



