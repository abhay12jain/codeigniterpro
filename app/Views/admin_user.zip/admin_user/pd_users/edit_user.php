<!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">

      <div class="toast-body text-white">

      </div>

    </div>

    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>

    <!-- Content Header (Page header) -->

    <div class="content-header">

      <div class="container-fluid">

        <div class="row mb-2">

          <div class="col-sm-6">

            <h1 class="m-0">Edit User</h1>

          </div><!-- /.col -->



        </div><!-- /.row -->

            <hr class="border-primary">

      </div><!-- /.container-fluid -->

    </div>

    <!-- /.content-header -->



    <!-- Main content -->

    <section class="content">

      <div class="container-fluid">

<div class="row mb-2">

          



    

     

    <?php if (session('msg')=='Data Not Updated.') { ?>

        <div class="alert alert-danger alert-dismissible" style="width:100%">

            <?= session('msg') ?>

            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>

        </div>



      <?php }else{ ?>

<?php if(session('msg')){?>

<div class="alert alert-info alert-dismissible" style="width:100%">

            <?= session('msg') ?>

            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>

        </div>



    <?php }} ?>

 

   

      <div class="col-md-9">

        <form  action="<?php echo base_url('AdminUserlist/update');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">



          <div class="form-group">

            <label for="formGroupExampleInput">Emoloyee ID</label>

            <!-- <input type="text" name="employee_id" class="form-control"> -->
            <input type="text" name="employee_id" class="form-control" value="<?php echo $user_obj['employee_id']; ?>">

            <input type="hidden" name="id" class="form-control" value="<?php echo $user_obj['id']; ?>">

          </div> 



          <div class="form-group">

            <label for="formGroupExampleInput">Full Name</label>

            <!-- <input type="text" name="full_name" class="form-control"> -->
            <input type="text" name="full_name" class="form-control" value="<?php echo $user_obj['full_name']; ?>">

          </div> 



          <div class="form-group">

            <label for="formGroupExampleInput">Email Id</label>

            <!-- <input type="text" name="email_id" class="form-control"> -->
            <input type="text" name="email_id" class="form-control" value="<?php echo $user_obj['email_id']; ?>">

          </div> 



          <div class="form-group">

            <label for="formGroupExampleInput">Phone Number</label>

            <!-- <input type="text" name="phone_number" class="form-control"> -->
            <input type="text" name="phone_number" class="form-control" value="<?php echo $user_obj['phone_number']; ?>">

          </div> 



           <div class="form-group">

            <label for="formGroupExampleInput">Password</label>

            <!-- <input type="text" name="password" class="form-control"> -->
            <input type="text" name="password" class="form-control" value="<?php echo $user_obj['password']; ?>">

          </div>

          <div class="form-group">

            <label for="formGroupExampleInput">Circle</label>

            <!-- <input type="text" name="circle" class="form-control"> -->
            <input type="text" name="circle" class="form-control" value="<?php echo $user_obj['circle']; ?>">

          </div> 

          <div class="form-group">

            <label for="formGroupExampleInput">Module</label>

            <!-- <input type="text" name="module" class="form-control"> -->
            <input type="text" name="module" class="form-control" value="<?php echo $user_obj['module']; ?>">

          </div> 


          <div class="form-group">
             <label for="formGroupExampleInput">Role</label></br> 
            <input type="checkbox" class="form-check-input ml-0" value="Technical" name="role[]" >
            <label class="form-check-label pr-4 pl-3" for="exampleCheck1"  >Technical</label>

            <input type="checkbox" class="form-check-input ml-0" value="Financial" name="role[]" >
            <label class="form-check-label pr-4 pl-3" for="exampleCheck1">Financial</label>

            <input type="checkbox" class="form-check-input ml-0" value="Comman" name="role[]" >
            <label class="form-check-label pr-4 pl-3" for="exampleCheck1">Comman </label>

            <input type="checkbox" class="form-check-input ml-0" value="One time" name="role[]" >
            <label class="form-check-label pr-4 pl-3" for="exampleCheck1">One time</label>
          </div>

          <div class="form-group">

            <label for="formGroupExampleInput">Company</label>

            <!-- <input type="text" name="company_name" class="form-control"> -->
            <input type="text" name="company_name" class="form-control" value="<?php echo $user_obj['company_name']; ?>">

          </div>   


          <!-- <div class="form-group">

            <label for="formGroupExampleInput">First Name</label>

            <input type="text" name="first_name" class="form-control" value="<?//php echo $user_obj['first_name']; ?>">

            <input type="hidden" name="id" class="form-control" value="<?//php echo $user_obj['id']; ?>">

           

          </div> 



          <div class="form-group">

            <label for="formGroupExampleInput">Last Name</label>

            <input type="text" name="last_name" class="form-control" value="<?//php echo $user_obj['last_name']; ?>">

          </div> 



          <div class="form-group">

            <label for="formGroupExampleInput">Email Id</label>

            <input type="text" name="email_id" class="form-control" value="<?//php echo $user_obj['email_id']; ?>">

          </div> 



          <div class="form-group">

            <label for="formGroupExampleInput">Phone Number</label>

            <input type="text" name="phone_number" class="form-control" value="<?//php echo $user_obj['phone_number']; ?>">

          </div> 



           <div class="form-group">

            <label for="formGroupExampleInput">Password</label>

            <input type="text" name="password" class="form-control" value="<?//php echo $user_obj['password']; ?>">

          </div> 



           



           <div class="form-group">

              <?//php if($user_obj['user_image']){ ?>

                          <img id="blah" src="<?//php echo base_url();?>/uploads/<?//php echo $user_obj['user_image']; ?>" class="" width="100" height="100"/>

              <?//php }else{?>

              <img id="blah" src="<?//php echo base_url(); ?>/assets/public/images/no-user.jpg" class="" width="100" height="100"/>

              <?//php } ?>

          </div>





          <div class="form-group">

            <label for="formGroupExampleInput">Upload Image</label>

            <input type="file" name="file" class="form-control" id="file" onchange="readURL(this);">

          </div>  -->

          



         

 

          <div class="form-group">

           <button type="submit" id="send_form" class="btn btn-success" >Update User</button>

          </div>

          

        </form>

      </div>

 

    </div>

  

</div>

       

      

    </section>

  

  

 

  

  </div>



