<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="toast-body text-white">
      </div>
    </div>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Edit Question</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
            <hr class="border-primary">
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
<div class="row mb-2">
          

    
     
    <?php if (session('msg')=='Data Not Updated.') { ?>
        <div class="alert alert-danger alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

      <?php }else{ ?>
<?php if(session('msg')){?>
<div class="alert alert-info alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

    <?php }} ?>
 
   
      <div class="col-md-9">
        <form  action="<?php echo base_url('credits/update_question');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">

          <div class="form-group">
            <label for="formGroupExampleInput">Question</label>
            <input type="text" name="questions" class="form-control" value="<?php echo $credit_question_obj['questions']; ?>">
            <input type="hidden" name="id" value="<?php echo $credit_question_obj['id']; ?>">
          </div> 

          <div class="form-group">
           <button type="submit" id="send_form" class="btn btn-success" >Update Question</button>
          </div>
          
        </form>
      </div>
 
    </div>
  
</div>
       
      
    </section>
  
  
 
  
  </div>

