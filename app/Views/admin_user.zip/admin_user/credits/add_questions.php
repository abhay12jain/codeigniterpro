 <?php $request = \Config\Services::request();
        $uri = $request->uri;
        $id = $uri->getSegments();
        $query = $uri->getQuery();

        ?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="toast-body text-white">
      </div>
    </div>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid mt-3">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h5 class="m-0">Add Credit Questions</h5>
          </div><!-- /.col -->

        </div><!-- /.row -->
            <hr class="border-primary">
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
<div class="row mb-2">
          

    
     
    <?php if (session('msg')=='Data Not Added.') { ?>
        <div class="alert alert-danger alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

      <?php }else{ 
       if(session('msg')){?>
        <div class="alert alert-info alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>
    <?php }} ?>
 
   
  <div class="col-md-9">

    <form  action="<?php echo base_url('credits/credit_questions_store');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
     <input type="hidden" name="company_id" value="<?php echo $id[2]; ?>">
      <div class="main_item">
<div class="items mb-4" data-group="test">
          <div class="form-group">
            <label for="formGroupExampleInput">Add Question</label>
            <!-- Repeater Content -->
  <div class="item-content">
    <div class="form-group">
      <div class="row align-items-center">
      <div class="col-10">
                <input class="form-control mt-0" name="credit_questions[]" placeholder="Enter Question">
      </div>
      <div class="col-2 ps-0">
          <div class="pull-right text-right repeater-remove-btn">
      <button id="remove-btn" class="btn fw-bold  py-2 px-0 lh-1" onclick="$(this).parents('.items').remove()">
          <img src="<?php echo base_url();?>/assets/public/dashboard/images/cross.png"  width="25px">
      </button>
  </div>
      </div>
    </div>
    </div>
  </div>
  </div> 
  </div> 
</div> 

   <div id="repeater">
  
</div>
  <div class="repeater-heading mb-4">
      <button type="button" class="btn btn-primary repeater-add-btn">Add More Question</button>
  </div>
  
  <div class="form-group text-right">
    <button type="submit" id="send_form" class="btn btn-success " >Add Question</button>
  </div>
          
        </form>


      </div>
 
    </div>
  </div>
</section>
</div>
<style type="text/css">
  .main_item >.items button {
    display: none;
}
</style>
<script type="text/javascript">
jQuery(function(){
  jQuery('.repeater-add-btn').click(function(){ 
  var item= jQuery(".items:last").clone(true).find("input").val('').end();
  item.appendTo("#repeater");
});
});
</script>