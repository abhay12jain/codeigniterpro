<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="toast-body text-white">
      </div>
    </div>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Testimonials</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
            <hr class="border-primary">
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
<div class="row mb-2">
          

    
     
    <?php if (session('msg')=='Data Not Updated.') { ?>
        <div class="alert alert-danger alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

      <?php }else{ ?>
<?php if(session('msg')){?>
<div class="alert alert-info alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

    <?php }} ?>
 
   
      <div class="col-md-9">
        <form  action="<?php echo base_url('page/update');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">

          <div class="form-group">
            <label for="formGroupExampleInput">Page Title</label>
   <input type="text" name="title_data" class="form-control" value="<?php echo $page_obj['page_title']; ?>">
            <input type="hidden" name="id" value="<?php echo $page_obj['id']; ?>">
          </div> 

          <div class="form-group">
            <label for="formGroupExampleInput">Description</label>
            
            <textarea class="form-control" id="testimonial_description" name="description"><?php echo $page_obj['page_description']; ?></textarea>
          </div> 

           <div class="form-group">
              <?php if($page_obj['featured_image']){ ?>
                          <img id="blah" src="<?php echo base_url();?>/uploads/<?php echo $page_obj['featured_image']; ?>" class="" width="100" height="100"/>
              <?php }else{?>
              <img id="blah" src="<?php echo base_url(); ?>/assets/public/images/no-user.jpg" class="" width="100" height="100"/>
              <?php } ?>
          </div>


          <div class="form-group">
            <label for="formGroupExampleInput">Upload Image</label>
            <input type="file" name="file" class="form-control" id="file" onchange="readURL(this);">
          </div> 
          

          <div class="form-group">
            <label for="formGroupExampleInput">Status</label>
            <select class="form-control" name="page_status">
              <option value="">Select</option>
              <option value="active" <?php if($page_obj['status']=='active'){echo 'selected=selected';} ?>>Active</option>
              <option value="in-active" <?php if($page_obj['status']=='in-active'){echo 'selected=selected';} ?>>Inactive</option>
              <option value="pending" <?php if($page_obj['status']=='pending'){echo 'selected=selected';} ?>>Pending</option>
            </select>
          </div> 

<div class="form-group mb-4 mt-4">
    <hr>
       <h4><label>SEO</label></h4>
   <hr>
</div>

          <div class="form-group">
            <label for="formGroupExampleInput">Meta Title</label>
            <input type="text" name="meta_title" class="form-control" value="<?php echo $page_obj['meta_title']; ?>">
          </div> 

          <div class="form-group">
            <label for="formGroupExampleInput">Meta Description</label>
            <textarea name="meta_description" class="form-control"><?php echo $page_obj['meta_description']; ?></textarea>
          </div> 

          <div class="form-group">
            <label for="formGroupExampleInput">Meta Keywords</label>
            <textarea name="meta_keywords" class="form-control"><?php echo $page_obj['meta_keywords']; ?></textarea>
          </div> 

 
          <div class="form-group">
           <button type="submit" id="send_form" class="btn btn-success" >Update Testimonial</button>
          </div>
          
        </form>

<?php if($page_obj['id']==1){ ?>
 <div class="other_options">
<h3>Other Page Options</h3>

      <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Pitchdeck Need</a>
    <a class="nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
    <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">


  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">

 
 
<form  action="<?php echo base_url('page/update_pitchdeck');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">

  <div class="form-group">
          <label for="formGroupExampleInput">Heading</label>
          <textarea class="form-control" name="pitchdeck_heading" id="pitchdeck_heading"><?php echo $pagesetting_obj['pitchdeck_heading']; ?></textarea>
          <input type="hidden" name="update_id" value="<?php echo $pagesetting_obj['id']; ?>">
          <input type="hidden" name="page_id" value="<?php echo $page_obj['id']; ?>">
        </div> 

        <div class="form-group">
              <?php if($pagesetting_obj['pitchdeck_left_img']){ ?>
                <img id="blah" src="<?php echo base_url();?>/uploads/<?php echo $pagesetting_obj['pitchdeck_left_img']; ?>" class="" width="100" height="100"/>
              <?php }else{?>
              <img id="blah" src="<?php echo base_url(); ?>/assets/public/images/no-user.jpg" class="" width="100" height="100"/><?php } ?>
        </div>

        <div class="form-group">
            <label for="formGroupExampleInput">Upload Image</label>
            <input type="file" name="pitch_file" class="form-control" id="pitch_file" onchange="readURL(this);">
        </div> 


        <div class="form-group">
          <label for="formGroupExampleInput">Desciption</label>
          <textarea class="form-control" name="pitchdeck_description" id="pitchdeck_description"><?php echo $pagesetting_obj['pitchdeck_description']; ?></textarea>
        </div> 

        <div class="form-group">
              <button type="submit" id="send_form" class="btn btn-success" >Submit</button>
        </div>

    </form>
   

   

  </div>

<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">2</div>
  <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">3</div>
</div>
    

</div> 

<?php }?>


      </div>
 
    </div>
  
</div>
       
      
    </section>
  
  
 
  
  </div>

