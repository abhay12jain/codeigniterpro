 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="toast-body text-white">
      </div>
    </div>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Add New Page</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
            <hr class="border-primary">
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
<div class="row mb-2">
          

    
     
    <?php if (session('msg')=='Data Not Added.') { ?>
        <div class="alert alert-danger alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

      <?php }else{ 
       if(session('msg')){?>
        <div class="alert alert-info alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>
    <?php }} ?>
 
   
  <div class="col-md-9">

    <form  action="<?php echo base_url('page/store');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">

          <div class="form-group">
            <label for="formGroupExampleInput">Page Title</label>
            <input type="text" name="title_data" class="form-control">
          </div> 

          

          <div class="form-group">
            <label for="formGroupExampleInput">Description</label>
            <!-- <input type="text" name="description" class="form-control"> -->
            <textarea class="form-control" id="testimonial_description" name="description"></textarea>
          </div> 

           <div class="form-group">
            <img id="blah" src="<?php echo base_url(); ?>/assets/public/images/no-user.jpg" class="" width="100" height="100"/>
          </div>

          <div class="form-group">
            <label for="formGroupExampleInput">Upload Image</label>
            <input type="file" name="file" class="form-control" id="file" onchange="readURL(this);">
          </div> 

          <div class="form-group">
            <label for="formGroupExampleInput">Status</label>
            <select class="form-control" name="page_status">
              <option value="">Select</option>
              <option value="active">Active</option>
              <option value="in-active">Inactive</option>
              <option value="pending">Pending</option>
            </select>
          </div> 
         

          <div class="form-group mb-4 mt-4">
              <hr><h4><label>SEO</label></h4><hr>
          </div>

          <div class="form-group">
            <label for="formGroupExampleInput">Meta Title</label>
            <input type="text" name="meta_title" class="form-control">
          </div> 

          <div class="form-group">
            <label for="formGroupExampleInput">Meta Description</label>
            <textarea name="meta_description" class="form-control"></textarea>
          </div> 

          <div class="form-group">
            <label for="formGroupExampleInput">Meta Keywords</label>
            <textarea name="meta_keywords" class="form-control"></textarea>
          </div> 

 
          <div class="form-group">
           <button type="submit" id="send_form" class="btn btn-success">Submit</button>
          </div>
          
        </form>


      </div>
 
    </div>
  </div>
</section>
</div>

