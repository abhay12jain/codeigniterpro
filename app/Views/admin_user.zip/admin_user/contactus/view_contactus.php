
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
     <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="toast-body text-white">
      </div>
    </div>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed"></div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">List Contact Users</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
            <hr class="border-primary">
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
         <div class="row mb-2">
          <?php if (session('msg')) { ?>
        <div class="alert alert-success alert-dismissible" style="width:100%">
            <?= session('msg') ?>
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        </div>

      <?php }?>

    <div class="card-body">
      <table class="table tabe-hover table-bordered" id="testimonial-list">
        <thead>
          <tr>
            <th class="text-center">#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Startup Stage</th>
            <th>Message</th>
            <th>Submit Date</th>
          </tr>
        </thead>
        <tbody>
         <?php if($contact_data){ foreach($contact_data as $credits_dataval){ ?>
          <tr>
            <th class="text-center"><?php echo $credits_dataval['id']; ?></th>
                
                    <td><b><?php echo $credits_dataval['name']; ?></b></td>
                    <td><b><?php echo $credits_dataval['email']; ?></b></td>
                    <td><b><?php echo $credits_dataval['phone_num']; ?></b></td>
                    <td><b><?php echo $credits_dataval['startup_stage']; ?></b></td>
                    <td><b><?php echo $credits_dataval['message']; ?></b></td>
                    <td><b><?php echo $credits_dataval['submit_date']; ?></b></td>
                <td class="text-center">
                  <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Action</button>
                  <div class="dropdown-menu" style="">
                      
                      <a class="dropdown-item delete_user" href="<?php echo base_url('delete_contact/'.$credits_dataval['id']);?>" onclick="return confirm('Are you sure you want to delete?');">Delete</a>
                  </div>
                </td>
          </tr> 

        <?php }}?>
     
        </tbody>
      </table>

      <!-- Pagination -->
      <div class="d-flex justify-content-end">
        <?php
//echo "<pre>";print_r($pager);
//echo $pager->default->uri->pageCount;
         if ($pager) :?>
        <?php $pagi_path= '/projects/etp/admin/view_contacts'; ?>
        <?php $pager->setPath($pagi_path); ?>
        <?= $pager->links(); ?>
        <?php endif ?>
      </div>
    </div>
     
   
 
   
 
        </div>
      </div>
    </section>


</div>

<?php //require_once 'admin_footer.php';?>
